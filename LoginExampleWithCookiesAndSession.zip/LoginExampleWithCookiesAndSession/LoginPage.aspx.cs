﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LoginExampleWithCookiesAndSession
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["person"]!=null)
            {
                if(Session["person"].ToString()=="vidya")
                {
                    Response.Redirect("LoginSuccess.aspx");
                }
            }

            HttpCookie c1 = Request.Cookies["MyData"];
            if(c1!=null)
            {
                txtUserName.Text = c1["id"];
                txtPassword.Text = c1["pass"];
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if(txtUserName.Text=="vidya" && txtPassword.Text=="vidya" && cbRememberMe.Checked)
            {

                HttpCookie c2 = new HttpCookie("MyData");
                c2["id"] = "vidya";
                c2["pass"] = "vidya";

                c2.Expires.Add(new TimeSpan(0, 200, 0));

                Response.Cookies.Add(c2);
                Session["person"] = c2["id"];
                Session.Timeout=1;
                Server.Transfer("LoginSuccess.aspx");
            }
        }
    }
}